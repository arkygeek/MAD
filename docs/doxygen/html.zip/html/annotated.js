var annotated =
[
    [ "Ui", "a00032.html", null ],
    [ "MadCategory", "a00001.html", "a00001" ],
    [ "MadData", "a00002.html", "a00002" ],
    [ "MadDataClassification", "a00003.html", "a00003" ],
    [ "MadGuid", "a00004.html", "a00004" ],
    [ "MadMainWindow", "a00005.html", "a00005" ],
    [ "MadModel", "a00006.html", "a00006" ],
    [ "MadSerialisable", "a00007.html", "a00007" ],
    [ "MadSubCategory", "a00008.html", "a00008" ],
    [ "MadTextDisplayForm", "a00009.html", "a00009" ],
    [ "MadUtils", "a00010.html", "a00010" ],
    [ "QDialog", "a00011.html", null ],
    [ "QMainWindow", "a00012.html", null ]
];