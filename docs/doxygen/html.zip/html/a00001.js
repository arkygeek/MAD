var a00001 =
[
    [ "MadData", "a00001.html#a2a1f2ab4197fdfcb39dd148ad275799c", null ],
    [ "MadData", "a00001.html#ad0204b1c96f0f75748e4c4c631375ce5", null ],
    [ "description", "a00001.html#aaf9c28a2ee3363dd2766adbbee12a890", null ],
    [ "fromXml", "a00001.html#a30677cb8685255a7939d401121525fb6", null ],
    [ "fromXmlFile", "a00001.html#a132a3ea21578307ae1afe074acc20d47", null ],
    [ "guid", "a00001.html#abd5fd246f0be83f0b9572363a78f66be", null ],
    [ "imageFile", "a00001.html#a5acf4019906ad50fd96a1815b08ac11a", null ],
    [ "name", "a00001.html#a83d295ac76b82edd24831a9800e275f6", null ],
    [ "operator=", "a00001.html#a694a4390c70108c9c55cea910dc29225", null ],
    [ "setDescription", "a00001.html#ac6aabfd092e0a2ce00a2f326e875946a", null ],
    [ "setGuid", "a00001.html#a899833db4b57903608571b737baa5a0a", null ],
    [ "setImageFile", "a00001.html#a649da13149edf70c2a9b6273b556bd7b", null ],
    [ "setName", "a00001.html#af9c155374899f439660bade71c095116", null ],
    [ "toHtml", "a00001.html#a985880da3130aa406964e9e8db4f0cee", null ],
    [ "toText", "a00001.html#a45a072ec3fee653ea15db10ab4d11156", null ],
    [ "toXml", "a00001.html#a73665b8eef0518c8c9b2df7d7565f5f8", null ],
    [ "toXmlFile", "a00001.html#a59ebe72f565f96ca7cae16f4a4f100b8", null ]
];