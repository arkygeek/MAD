var a00041 =
[
    [ "retranslateUi", "a00041.html#ac6674c79999df1dc270a4bbc7a17e2e6", null ],
    [ "retranslateUi", "a00041.html#ac6674c79999df1dc270a4bbc7a17e2e6", null ],
    [ "setupUi", "a00041.html#a6d170b1b50d441ac7e3e692b8a6674ab", null ],
    [ "setupUi", "a00041.html#a6d170b1b50d441ac7e3e692b8a6674ab", null ],
    [ "buttonBox", "a00041.html#a150b323a424be11d3180063fb9ef4360", null ],
    [ "gridLayout", "a00041.html#a10eb394b2f96f5122d7056b22c3dca50", null ],
    [ "textBrowser", "a00041.html#adaa7cee150703712df34f67ee6d39f1d", null ]
];