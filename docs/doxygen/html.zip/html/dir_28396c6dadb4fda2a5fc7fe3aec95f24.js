var dir_28396c6dadb4fda2a5fc7fe3aec95f24 =
[
    [ "mad.h", "a00017.html", "a00017" ],
    [ "maddata.cpp", "a00018.html", null ],
    [ "maddata.h", "a00019.html", [
      [ "MadSubCategory", "a00008.html", "a00008" ],
      [ "MadCategory", "a00001.html", "a00001" ],
      [ "MadData", "a00002.html", "a00002" ]
    ] ],
    [ "madguid.cpp", "a00020.html", null ],
    [ "madguid.h", "a00021.html", [
      [ "MadGuid", "a00004.html", "a00004" ]
    ] ],
    [ "madmodel.cpp", "a00022.html", null ],
    [ "madmodel.h", "a00023.html", [
      [ "MadModel", "a00006.html", "a00006" ]
    ] ],
    [ "madserialisable.cpp", "a00024.html", null ],
    [ "madserialisable.h", "a00025.html", [
      [ "MadSerialisable", "a00007.html", "a00007" ]
    ] ],
    [ "madutils.cpp", "a00026.html", null ],
    [ "madutils.h", "a00027.html", [
      [ "MadUtils", "a00010.html", "a00010" ]
    ] ],
    [ "madversion.h", "a00028.html", "a00028" ]
];