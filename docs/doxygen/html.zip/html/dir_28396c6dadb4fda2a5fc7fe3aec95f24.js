var dir_28396c6dadb4fda2a5fc7fe3aec95f24 =
[
    [ "dataclassification", "dir_e9d674ba6e528ec7ea3d1b54e51262a0.html", "dir_e9d674ba6e528ec7ea3d1b54e51262a0" ],
    [ "mad.h", "a00055.html", "a00055" ],
    [ "maddata.cpp", "a00056.html", null ],
    [ "maddata.h", "a00057.html", [
      [ "MadData", "a00001.html", "a00001" ]
    ] ],
    [ "maddataset.cpp", "a00058.html", null ],
    [ "maddataset.h", "a00059.html", [
      [ "MadDataset", "a00010.html", "a00010" ]
    ] ],
    [ "madguid.cpp", "a00060.html", null ],
    [ "madguid.h", "a00061.html", [
      [ "MadGuid", "a00011.html", "a00011" ]
    ] ],
    [ "madmodel.cpp", "a00062.html", null ],
    [ "madmodel.h", "a00063.html", [
      [ "MadModel", "a00013.html", "a00013" ]
    ] ],
    [ "madserialisable.cpp", "a00064.html", null ],
    [ "madserialisable.h", "a00065.html", [
      [ "MadSerialisable", "a00014.html", "a00014" ]
    ] ],
    [ "madutils.cpp", "a00066.html", null ],
    [ "madutils.h", "a00067.html", [
      [ "MadUtils", "a00022.html", "a00022" ]
    ] ],
    [ "madversion.h", "a00068.html", "a00068" ]
];