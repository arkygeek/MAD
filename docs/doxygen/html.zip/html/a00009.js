var a00009 =
[
    [ "MadTextDisplayForm", "a00009.html#a909d8a306de0d17af1d2baff70fe1a98", null ],
    [ "~MadTextDisplayForm", "a00009.html#a6309fa7f9125553b883259819e5e4257", null ],
    [ "setText", "a00009.html#aec3e8c78fd53dba8a037b16ade6461e4", null ]
];