var a00079 =
[
    [ "makeString", "a00079.html#af5534ad7b1a38b45b4108fbb8ff3664f", null ]
];