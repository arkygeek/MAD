var hierarchy =
[
    [ "MadCategory", "a00001.html", null ],
    [ "MadDataClassification", null, [
      [ "MadDataClassification", "a00003.html", null ]
    ] ],
    [ "MadGuid", "a00004.html", [
      [ "MadData", "a00002.html", null ],
      [ "MadModel", "a00006.html", null ]
    ] ],
    [ "MadMainWindow", null, [
      [ "MadMainWindow", "a00005.html", null ]
    ] ],
    [ "MadSerialisable", "a00007.html", [
      [ "MadData", "a00002.html", null ],
      [ "MadModel", "a00006.html", null ]
    ] ],
    [ "MadSubCategory", "a00008.html", null ],
    [ "MadUtils", "a00010.html", null ],
    [ "QDialog", "a00011.html", [
      [ "MadDataClassification", "a00003.html", null ],
      [ "MadTextDisplayForm", "a00009.html", null ]
    ] ],
    [ "QMainWindow", "a00012.html", [
      [ "MadMainWindow", "a00005.html", null ]
    ] ]
];