var searchData=
[
  ['mindata',['minData',['../a00008.html#a3728af78f99ce0a8c3be3165626862db',1,'MadSubCategory']]]
];
