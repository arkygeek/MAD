var searchData=
[
  ['observations',['observations',['../a00008.html#a7ac12663efbd43f8bb85449c4783523d',1,'MadSubCategory']]]
];
