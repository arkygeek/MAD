var searchData=
[
  ['description',['description',['../a00002.html#aaf9c28a2ee3363dd2766adbbee12a890',1,'MadData::description()'],['../a00006.html#a424649185054ab1c5e09ce1b7f14bd3b',1,'MadModel::description()']]]
];
