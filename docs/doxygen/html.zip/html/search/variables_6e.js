var searchData=
[
  ['name',['name',['../a00008.html#a0f0d32eb25cfe2236b5b68a65f3bda0a',1,'MadSubCategory::name()'],['../a00001.html#af8fe4e8d21720e18b05210a43b2108c2',1,'MadCategory::name()']]]
];
