var searchData=
[
  ['regional',['Regional',['../a00017.html#a8e8d3da3ac3510ba6f5aa1a4c8c82eaea01515e2441bfa7123d0c58e04371d5dd',1,'mad.h']]],
  ['replicates',['replicates',['../a00008.html#aa2238ad9a0d06d1d35c88c6c6c508270',1,'MadSubCategory']]]
];
