var searchData=
[
  ['kcalories',['KCalories',['../a00017.html#a7a6534a55fc72bbcb547056b9eb694edaf01989f7865a5d3e380a68985117766a',1,'mad.h']]]
];
