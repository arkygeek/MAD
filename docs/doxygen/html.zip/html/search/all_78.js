var searchData=
[
  ['xmldecode',['xmlDecode',['../a00010.html#aee37612e0cc8aeafe2614b018e5d2c4d',1,'MadUtils']]],
  ['xmlencode',['xmlEncode',['../a00010.html#ae6d98beebaf217ce2d630644412eabf2',1,'MadUtils']]]
];
