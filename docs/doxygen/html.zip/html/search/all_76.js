var searchData=
[
  ['version',['VERSION',['../a00028.html#a1c6d5de492ac61ad29aec7aa9a436bbf',1,'madversion.h']]]
];
