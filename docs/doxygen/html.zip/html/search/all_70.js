var searchData=
[
  ['platinum',['Platinum',['../a00017.html#ab6ad47405d01eb611996d855bef0610daba976230e236daa04305650837dfed81',1,'mad.h']]]
];
