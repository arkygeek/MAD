var searchData=
[
  ['name',['name',['../a00002.html#a83d295ac76b82edd24831a9800e275f6',1,'MadData::name()'],['../a00006.html#aaad4ceb50f8a4422582c712050469fd7',1,'MadModel::name()']]]
];
