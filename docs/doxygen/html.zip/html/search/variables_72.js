var searchData=
[
  ['replicates',['replicates',['../a00008.html#aa2238ad9a0d06d1d35c88c6c6c508270',1,'MadSubCategory']]]
];
