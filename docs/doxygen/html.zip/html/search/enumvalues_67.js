var searchData=
[
  ['global',['Global',['../a00017.html#a8e8d3da3ac3510ba6f5aa1a4c8c82eaea03ddcda8467f404189c984dc13409aa8',1,'mad.h']]],
  ['gold',['Gold',['../a00017.html#ab6ad47405d01eb611996d855bef0610da4fe767077a795c957f76faf02f3ca765',1,'mad.h']]]
];
