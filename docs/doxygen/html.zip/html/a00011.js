var a00011 =
[
    [ "MadGuid", "a00011.html#a119759ea390708eab3df016639b01cc7", null ],
    [ "guid", "a00011.html#abd5fd246f0be83f0b9572363a78f66be", null ],
    [ "setGuid", "a00011.html#a899833db4b57903608571b737baa5a0a", null ]
];