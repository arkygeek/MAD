var a00018 =
[
    [ "MadSubCategory", "a00018.html#ad7067e3712c460e6a6ab5080bae3f8c2", null ],
    [ "MadSubCategory", "a00018.html#a0519ca0440e9d147c961d737d18ca922", null ],
    [ "depth", "a00018.html#ab87789547205f2983904e8d0c3b85956", null ],
    [ "fromXml", "a00018.html#a92d80c196fe95f14f3e33c34d7fa0e62", null ],
    [ "minData", "a00018.html#abde9125e80aed54dcd0846b9c35db658", null ],
    [ "observations", "a00018.html#a1850a8bb9432e2b974d58c71775486a4", null ],
    [ "operator=", "a00018.html#a6c5aa44d09b401d25817b554ede4d938", null ],
    [ "replicates", "a00018.html#a257135a0abeacd881f01322f4ceae00f", null ],
    [ "setDepth", "a00018.html#a6145d6d212a65cc9961fa066bd680eb5", null ],
    [ "setMinData", "a00018.html#a83a44e4a046fa5250661232e7f2dee52", null ],
    [ "setObservations", "a00018.html#a65495a0b2d88bb74be624d5e478f0915", null ],
    [ "setReplicates", "a00018.html#add9e863bd9f1d0ce1921c294d46a17fd", null ],
    [ "setWeightPoints", "a00018.html#a72953f2a4d7dd2f6402c54f53c0f6cde", null ],
    [ "toHtml", "a00018.html#a84760c22823a4879e22231525c067751", null ],
    [ "toText", "a00018.html#aa09d8a7d17ccb9b5abf441525672de8e", null ],
    [ "toXml", "a00018.html#ac928ace3e13c2f224779f24ed160b010", null ],
    [ "weightPoints", "a00018.html#a4e110112a6881b59dd5002543cacadbf", null ]
];