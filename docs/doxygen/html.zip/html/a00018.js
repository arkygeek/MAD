var a00018 =
[
    [ "MadSVObservations", "a00018.html#af89c06b7750b1d0f9fb29ed12210e832", null ],
    [ "MadSVObservations", "a00018.html#ad96fc49c08145f7abdc9719e9d6454b2", null ],
    [ "damages", "a00018.html#a1d477977b002421176b377bc7845392b", null ],
    [ "fromXml", "a00018.html#afaeb1312cd9d65e05a0cac66a4a66155", null ],
    [ "fromXmlFile", "a00018.html#a132a3ea21578307ae1afe074acc20d47", null ],
    [ "guid", "a00018.html#abd5fd246f0be83f0b9572363a78f66be", null ],
    [ "lodging", "a00018.html#aae4edad0658f58180def467929c1767d", null ],
    [ "operator=", "a00018.html#a75042cc57d38805251538cf80f6ea076", null ],
    [ "pestsOrDiseases", "a00018.html#a5e7eef28664df87596a70d196b4dce86", null ],
    [ "setDamages", "a00018.html#ab3e250b42d71523cf0a9b8274b33ead6", null ],
    [ "setGuid", "a00018.html#a899833db4b57903608571b737baa5a0a", null ],
    [ "setLodging", "a00018.html#ad1263ef3afd2055aed661d9ee44c42e1", null ],
    [ "setPestsOrDiseases", "a00018.html#ada06c617533eabce0f1fc07a3d83ddef", null ],
    [ "toHtml", "a00018.html#ac236bdfbbd210512586d69138cd55324", null ],
    [ "toText", "a00018.html#a72add57ef8beef4fb38fe0e2785e9042", null ],
    [ "toXml", "a00018.html#ae98e94cc4ff0c030f8d46c38a90da2c4", null ],
    [ "toXmlFile", "a00018.html#a59ebe72f565f96ca7cae16f4a4f100b8", null ]
];