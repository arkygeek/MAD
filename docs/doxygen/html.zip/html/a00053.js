var a00053 =
[
    [ "qCleanupResources_resources", "a00053.html#aed07cf98f1bcc47e6707bf1b60675291", null ],
    [ "qInitResources_resources", "a00053.html#a9df9503dae688e1ed736f03bf343b6ac", null ],
    [ "qRegisterResourceData", "a00053.html#ab3bec3d1e679084be46edc41e4c91bc1", null ],
    [ "qUnregisterResourceData", "a00053.html#ad65f8bca8010dd1fd135a28a085c6d03", null ]
];