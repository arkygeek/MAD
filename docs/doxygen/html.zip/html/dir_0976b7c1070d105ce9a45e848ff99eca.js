var dir_0976b7c1070d105ce9a45e848ff99eca =
[
    [ "gui", "dir_d222dbe04ff54d8eba0bc52be3b729c4.html", "dir_d222dbe04ff54d8eba0bc52be3b729c4" ],
    [ "lib", "dir_28396c6dadb4fda2a5fc7fe3aec95f24.html", "dir_28396c6dadb4fda2a5fc7fe3aec95f24" ],
    [ "madmainwindow.cpp", "a00029.html", null ],
    [ "madmainwindow.h", "a00030.html", [
      [ "MadMainWindow", "a00005.html", "a00005" ]
    ] ],
    [ "main.cpp", "a00031.html", "a00031" ]
];