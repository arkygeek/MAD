var dir_0976b7c1070d105ce9a45e848ff99eca =
[
    [ "build", "dir_ceae39d8f3603b16f4f79eeb14af4f3b.html", "dir_ceae39d8f3603b16f4f79eeb14af4f3b" ],
    [ "buildKDevelop", "dir_e315b27c76eea60d54949fd16f8b00cf.html", "dir_e315b27c76eea60d54949fd16f8b00cf" ],
    [ "buildXcode", "dir_849c3ac428447e0bb808e547378ac33d.html", "dir_849c3ac428447e0bb808e547378ac33d" ],
    [ "gui", "dir_d222dbe04ff54d8eba0bc52be3b729c4.html", "dir_d222dbe04ff54d8eba0bc52be3b729c4" ],
    [ "lib", "dir_28396c6dadb4fda2a5fc7fe3aec95f24.html", "dir_28396c6dadb4fda2a5fc7fe3aec95f24" ],
    [ "madmainwindow.cpp", "a00123.html", null ],
    [ "madmainwindow.h", "a00124.html", [
      [ "MadMainWindow", "a00014.html", "a00014" ]
    ] ],
    [ "main.cpp", "a00125.html", "a00125" ]
];