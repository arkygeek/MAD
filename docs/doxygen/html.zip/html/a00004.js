var a00004 =
[
    [ "MadDataClassificationInitialValues", "a00004.html#a4a9af9a0391010ab87f303e3306dd49e", null ],
    [ "MadDataClassificationInitialValues", "a00004.html#acef338038be0fb49c4cac184979b132f", null ],
    [ "fromXml", "a00004.html#a4fb533e66e304e163e010f4814d08d18", null ],
    [ "fromXmlFile", "a00004.html#a132a3ea21578307ae1afe074acc20d47", null ],
    [ "guid", "a00004.html#abd5fd246f0be83f0b9572363a78f66be", null ],
    [ "nitrogenMin", "a00004.html#a91abea92f437ad55275bf460c83908fd", null ],
    [ "operator=", "a00004.html#a81d5d7d8e9b59e859cf7c3183b7351f0", null ],
    [ "setGuid", "a00004.html#a899833db4b57903608571b737baa5a0a", null ],
    [ "setNitrogenMin", "a00004.html#a41b340a67d9e43ec72933ec955687dc5", null ],
    [ "setSoilMoisture", "a00004.html#a12ec30acc0625f3ff00dfecc3cdc1676", null ],
    [ "soilMoisture", "a00004.html#ae9faf4319c6e901e148f8224958bc00c", null ],
    [ "toHtml", "a00004.html#a60417c38988292c8e9ab971636f6d618", null ],
    [ "toText", "a00004.html#ae662adc25a39e0e9355ab3c0dfa410f3", null ],
    [ "toXml", "a00004.html#a5e1774c7f338d448448e2ec7b0351476", null ],
    [ "toXmlFile", "a00004.html#a59ebe72f565f96ca7cae16f4a4f100b8", null ]
];