var a00012 =
[
    [ "MadMainWindow", "a00012.html#adb4f90643637c6d6f89fb77c25ced55b", null ],
    [ "changeEvent", "a00012.html#af9c57e0984b87146a1de895bc1a5b54b", null ],
    [ "modelText", "a00012.html#a1c3349166cd127587b99d54657e45e5c", null ],
    [ "setModelText", "a00012.html#ab941397fcef740a3924f64642dc7ae7d", null ]
];