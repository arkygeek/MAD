var a00020 =
[
    [ "MadSVObservations", "a00020.html#af89c06b7750b1d0f9fb29ed12210e832", null ],
    [ "MadSVObservations", "a00020.html#ad96fc49c08145f7abdc9719e9d6454b2", null ],
    [ "damages", "a00020.html#a1d477977b002421176b377bc7845392b", null ],
    [ "fromXml", "a00020.html#afaeb1312cd9d65e05a0cac66a4a66155", null ],
    [ "lodging", "a00020.html#aae4edad0658f58180def467929c1767d", null ],
    [ "operator=", "a00020.html#a75042cc57d38805251538cf80f6ea076", null ],
    [ "pestsOrDiseases", "a00020.html#a5e7eef28664df87596a70d196b4dce86", null ],
    [ "setDamages", "a00020.html#ab3e250b42d71523cf0a9b8274b33ead6", null ],
    [ "setLodging", "a00020.html#ad1263ef3afd2055aed661d9ee44c42e1", null ],
    [ "setPestsOrDiseases", "a00020.html#ada06c617533eabce0f1fc07a3d83ddef", null ],
    [ "toHtml", "a00020.html#ac236bdfbbd210512586d69138cd55324", null ],
    [ "toText", "a00020.html#a72add57ef8beef4fb38fe0e2785e9042", null ],
    [ "toXml", "a00020.html#ae98e94cc4ff0c030f8d46c38a90da2c4", null ]
];