var a00020 =
[
    [ "MadSVSurfaceFluxes", "a00020.html#a9bf00d385b7f3f0d229721bd3541566a", null ],
    [ "MadSVSurfaceFluxes", "a00020.html#a6a1c68b02b5b45369be15b47fab750b3", null ],
    [ "ch4Loss", "a00020.html#a2d1e7ef5397cc80046b6e6cea9a6fb37", null ],
    [ "et", "a00020.html#a277a982167092b20bc992a00251e6ed2", null ],
    [ "fromXml", "a00020.html#a907a37d5d6fea37585e5407a038708e5", null ],
    [ "fromXmlFile", "a00020.html#a132a3ea21578307ae1afe074acc20d47", null ],
    [ "guid", "a00020.html#abd5fd246f0be83f0b9572363a78f66be", null ],
    [ "n2Loss", "a00020.html#ac2a3a79cbe7280d58c70a8fadd6d3d7f", null ],
    [ "n2oLoss", "a00020.html#a702aa4baf9bfe3dba6a84d873bd7b4d2", null ],
    [ "nh3Loss", "a00020.html#acc2244ad421ef5724e2e36dda95a5713", null ],
    [ "operator=", "a00020.html#af1cefa3bc4456d94f2a59ae9ba0e701c", null ],
    [ "setCh4Loss", "a00020.html#a3a67dc27afcd5c4e1c758d2484501ead", null ],
    [ "setEt", "a00020.html#a29bbb18e774a0f1f56df2e1de0137766", null ],
    [ "setGuid", "a00020.html#a899833db4b57903608571b737baa5a0a", null ],
    [ "setN2Loss", "a00020.html#a688018b171e194fee0634d47c0cc4fc0", null ],
    [ "setN2oLoss", "a00020.html#aa0e198c65675db1fd64dfb2ae9671f90", null ],
    [ "setNh3Loss", "a00020.html#a11d5333a813ec07ad23fdd115fa50df4", null ],
    [ "toHtml", "a00020.html#a5b7fa19ed8ca343e49fb4279d67a14ea", null ],
    [ "toText", "a00020.html#addf8df76d59f64699c6d22636355d499", null ],
    [ "toXml", "a00020.html#ab00948eeb99131e8b55095695b36981b", null ],
    [ "toXmlFile", "a00020.html#a59ebe72f565f96ca7cae16f4a4f100b8", null ]
];