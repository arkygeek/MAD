var a00038 =
[
    [ "mCH4Loss", "a00038.html#af2c9c62458383f9e517025ab58978bd3", null ],
    [ "mEt", "a00038.html#ae87711d684dae7525defd9cf97ef49b2", null ],
    [ "mN2Loss", "a00038.html#adb6b48a3518d990cb4a5bc1cee1c4de7", null ],
    [ "mN2OLosse", "a00038.html#a247acf491d582cfb5896ce69714a6107", null ],
    [ "mNH3Loss", "a00038.html#a3044e41a2db94783b791659488d72047", null ]
];