var a00002 =
[
    [ "MadData", "a00002.html#a2a1f2ab4197fdfcb39dd148ad275799c", null ],
    [ "MadData", "a00002.html#ad0204b1c96f0f75748e4c4c631375ce5", null ],
    [ "description", "a00002.html#aaf9c28a2ee3363dd2766adbbee12a890", null ],
    [ "fromXml", "a00002.html#a30677cb8685255a7939d401121525fb6", null ],
    [ "imageFile", "a00002.html#a5acf4019906ad50fd96a1815b08ac11a", null ],
    [ "name", "a00002.html#a83d295ac76b82edd24831a9800e275f6", null ],
    [ "operator=", "a00002.html#a694a4390c70108c9c55cea910dc29225", null ],
    [ "setDescription", "a00002.html#ac6aabfd092e0a2ce00a2f326e875946a", null ],
    [ "setImageFile", "a00002.html#a649da13149edf70c2a9b6273b556bd7b", null ],
    [ "setName", "a00002.html#af9c155374899f439660bade71c095116", null ],
    [ "toHtml", "a00002.html#a985880da3130aa406964e9e8db4f0cee", null ],
    [ "toText", "a00002.html#a45a072ec3fee653ea15db10ab4d11156", null ],
    [ "toXml", "a00002.html#a73665b8eef0518c8c9b2df7d7565f5f8", null ]
];