var a00022 =
[
    [ "MadSVSurfaceFluxes", "a00022.html#a9bf00d385b7f3f0d229721bd3541566a", null ],
    [ "MadSVSurfaceFluxes", "a00022.html#a6a1c68b02b5b45369be15b47fab750b3", null ],
    [ "ch4Loss", "a00022.html#a2d1e7ef5397cc80046b6e6cea9a6fb37", null ],
    [ "et", "a00022.html#a277a982167092b20bc992a00251e6ed2", null ],
    [ "fromXml", "a00022.html#a907a37d5d6fea37585e5407a038708e5", null ],
    [ "n2Loss", "a00022.html#ac2a3a79cbe7280d58c70a8fadd6d3d7f", null ],
    [ "n2oLoss", "a00022.html#a702aa4baf9bfe3dba6a84d873bd7b4d2", null ],
    [ "nh3Loss", "a00022.html#acc2244ad421ef5724e2e36dda95a5713", null ],
    [ "operator=", "a00022.html#af1cefa3bc4456d94f2a59ae9ba0e701c", null ],
    [ "setCh4Loss", "a00022.html#a3a67dc27afcd5c4e1c758d2484501ead", null ],
    [ "setEt", "a00022.html#a29bbb18e774a0f1f56df2e1de0137766", null ],
    [ "setN2Loss", "a00022.html#a688018b171e194fee0634d47c0cc4fc0", null ],
    [ "setN2oLoss", "a00022.html#aa0e198c65675db1fd64dfb2ae9671f90", null ],
    [ "setNh3Loss", "a00022.html#a11d5333a813ec07ad23fdd115fa50df4", null ],
    [ "toHtml", "a00022.html#a5b7fa19ed8ca343e49fb4279d67a14ea", null ],
    [ "toText", "a00022.html#addf8df76d59f64699c6d22636355d499", null ],
    [ "toXml", "a00022.html#ab00948eeb99131e8b55095695b36981b", null ]
];