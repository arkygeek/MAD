var a00007 =
[
    [ "MadDataClassificationPrevCrop", "a00007.html#ac2e71411a680df519383f93650c0082a", null ],
    [ "MadDataClassificationPrevCrop", "a00007.html#a75676f70edbb0b563a5779581bfe7c22", null ],
    [ "crop", "a00007.html#aae07ab8c10a5d9175efc38ed56060d42", null ],
    [ "fertilisation", "a00007.html#a78e4818ff810414cbace90f6f0f2bd41", null ],
    [ "fromXml", "a00007.html#af9aed87632a7c94ea291899df1fb14f7", null ],
    [ "harvestDate", "a00007.html#ad893cf64f43a9d86c439a15cf458d491", null ],
    [ "irrigation", "a00007.html#a340d007b4f9218d1b32cb4cbc8857039", null ],
    [ "operator=", "a00007.html#aca55cffce0d5970182018166c1bb40a2", null ],
    [ "residueMgmt", "a00007.html#a0ac859b74396f2495146a89e663aeb82", null ],
    [ "setCrop", "a00007.html#aa0690ffc2c2905b3924c18134eee409f", null ],
    [ "setFertilisation", "a00007.html#a1153482e9e5fbe82b0c894e255ad4dbe", null ],
    [ "setHarvestDate", "a00007.html#af2b990ac7adfa7d7af62b5491ef92d02", null ],
    [ "setIrrigation", "a00007.html#a70373a60d375181e00854f3411f669b4", null ],
    [ "setResidueMgmt", "a00007.html#ac9660b612a9813770cda8d75ef9217ad", null ],
    [ "setSowingDate", "a00007.html#a12d7ef6c239e2a351eebd6f49f0e1d33", null ],
    [ "setYield", "a00007.html#a999da0f586e489975ed17fdedd5fa7cf", null ],
    [ "sowingDate", "a00007.html#a6f9b8ab361692280c8afa93a016554f8", null ],
    [ "toHtml", "a00007.html#a2f72e682f0773057ef250437e13e4725", null ],
    [ "toText", "a00007.html#ae9f5353241663202824db64abac93653", null ],
    [ "toXml", "a00007.html#af2e268701c06670e3afaedc9636d3378", null ],
    [ "yield", "a00007.html#a896c5bb6c2c336978eecc76547f29068", null ]
];