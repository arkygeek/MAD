var a00007 =
[
    [ "MadDataClassificationSiteData", "a00007.html#a297f5e9351f5eb1b363f0faa492c714c", null ],
    [ "MadDataClassificationSiteData", "a00007.html#a918aa7dff22b081ad41fb6fc9f192b9f", null ],
    [ "altitude", "a00007.html#a5cd0bd77ffe352d81f3a962689c861ed", null ],
    [ "fromXml", "a00007.html#aac19a437c245ba7c77c5837f82dd644c", null ],
    [ "fromXmlFile", "a00007.html#a132a3ea21578307ae1afe074acc20d47", null ],
    [ "guid", "a00007.html#abd5fd246f0be83f0b9572363a78f66be", null ],
    [ "latitude", "a00007.html#aadb2a5a967e9c9641900e827b111e121", null ],
    [ "longitude", "a00007.html#ace0fc76675b8402fdec9e2c68abdd64f", null ],
    [ "operator=", "a00007.html#a0d4146087e555cd06b58ac7c3925faaa", null ],
    [ "setAltitude", "a00007.html#a19c34fa46698768264a61ba6dff34c81", null ],
    [ "setGuid", "a00007.html#a899833db4b57903608571b737baa5a0a", null ],
    [ "setLatitude", "a00007.html#a3deb34ce66b910a19acfca07c9bce50e", null ],
    [ "setLongitude", "a00007.html#a31333df2057730f425158332805858c8", null ],
    [ "toHtml", "a00007.html#aff488f0ebe314346f448b500f4be4bb9", null ],
    [ "toText", "a00007.html#a79ee2d49b5475294cac901a6bef190a9", null ],
    [ "toXml", "a00007.html#aba69186b9010ecb10a06131b11a889a3", null ],
    [ "toXmlFile", "a00007.html#a59ebe72f565f96ca7cae16f4a4f100b8", null ]
];