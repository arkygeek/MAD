var a00076 =
[
    [ "MadDataClassification", "a00010.html", null ],
    [ "MadMainWindow", "a00013.html", null ],
    [ "MadTextDisplayForm", "a00018.html", null ]
];