var a00042 =
[
    [ "mGlobalRadiation", "a00042.html#ad9718eb44458f33c01582a969c98ca4a", null ],
    [ "mLeafWetness", "a00042.html#aa6fd81b09151581c06038120a8e009a1", null ],
    [ "mPrecipitation", "a00042.html#a75c0c51512de48b09be97e595f7d39a3", null ],
    [ "mRelativeHumidity", "a00042.html#ac2cf901095b9872bb9d864aafdb1dc0e", null ],
    [ "mSoilTemp", "a00042.html#a98989376939283e5bee60a0f9f2afd9b", null ],
    [ "mSunshineHours", "a00042.html#a073a9a4c1187dc50491f0c5432a5f484", null ],
    [ "mTAve", "a00042.html#aa9d825c28b7237ced0968a73911d8975", null ],
    [ "mTMax", "a00042.html#a0820dff233fb01f2574e1c4e9965d6eb", null ],
    [ "mTMin", "a00042.html#a9f67376a2391722c3415d932f4b36b2d", null ],
    [ "mWindSpeed", "a00042.html#a689a163c5ad6b5cdb1387f94785daaa8", null ]
];