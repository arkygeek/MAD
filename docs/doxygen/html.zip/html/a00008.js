var a00008 =
[
    [ "depth", "a00008.html#a5514fc9730d13a3c18eaf002bf96bd72", null ],
    [ "minData", "a00008.html#a3728af78f99ce0a8c3be3165626862db", null ],
    [ "name", "a00008.html#a0f0d32eb25cfe2236b5b68a65f3bda0a", null ],
    [ "observations", "a00008.html#a7ac12663efbd43f8bb85449c4783523d", null ],
    [ "replicates", "a00008.html#aa2238ad9a0d06d1d35c88c6c6c508270", null ],
    [ "weightPoints", "a00008.html#a5aa8b532f2decce8a584b7cbb2b0816c", null ]
];