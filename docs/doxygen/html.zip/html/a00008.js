var a00008 =
[
    [ "MadDataClassificationSiteData", "a00008.html#a297f5e9351f5eb1b363f0faa492c714c", null ],
    [ "MadDataClassificationSiteData", "a00008.html#a918aa7dff22b081ad41fb6fc9f192b9f", null ],
    [ "altitude", "a00008.html#a5cd0bd77ffe352d81f3a962689c861ed", null ],
    [ "fromXml", "a00008.html#aac19a437c245ba7c77c5837f82dd644c", null ],
    [ "latitude", "a00008.html#aadb2a5a967e9c9641900e827b111e121", null ],
    [ "longitude", "a00008.html#ace0fc76675b8402fdec9e2c68abdd64f", null ],
    [ "operator=", "a00008.html#a0d4146087e555cd06b58ac7c3925faaa", null ],
    [ "setAltitude", "a00008.html#a19c34fa46698768264a61ba6dff34c81", null ],
    [ "setLatitude", "a00008.html#a3deb34ce66b910a19acfca07c9bce50e", null ],
    [ "setLongitude", "a00008.html#a31333df2057730f425158332805858c8", null ],
    [ "toHtml", "a00008.html#aff488f0ebe314346f448b500f4be4bb9", null ],
    [ "toText", "a00008.html#a79ee2d49b5475294cac901a6bef190a9", null ],
    [ "toXml", "a00008.html#aba69186b9010ecb10a06131b11a889a3", null ]
];