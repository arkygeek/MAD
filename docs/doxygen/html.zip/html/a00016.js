var a00016 =
[
    [ "MadSerialisable", "a00016.html#aa2f63236e869cf3237cf4b31194550c5", null ],
    [ "fromXml", "a00016.html#a37d5fc3b08cddd05c4ddffdf3fd43535", null ],
    [ "fromXmlFile", "a00016.html#a132a3ea21578307ae1afe074acc20d47", null ],
    [ "toXml", "a00016.html#ad54654484660b5b0391f5e8765070ec8", null ],
    [ "toXmlFile", "a00016.html#a59ebe72f565f96ca7cae16f4a4f100b8", null ]
];