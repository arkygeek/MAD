var a00006 =
[
    [ "MadModel", "a00006.html#af27ca3c9c638a960822924193786d0e9", null ],
    [ "MadModel", "a00006.html#af8cf7ab044805122243b9153cc56e733", null ],
    [ "description", "a00006.html#a424649185054ab1c5e09ce1b7f14bd3b", null ],
    [ "fromXml", "a00006.html#ada33c0eed39499b58d0a886566732607", null ],
    [ "imageFile", "a00006.html#abd250700ecd6b39bb105bd4700df7026", null ],
    [ "name", "a00006.html#aaad4ceb50f8a4422582c712050469fd7", null ],
    [ "operator=", "a00006.html#a8c064230a0f61bafb7a546a565934585", null ],
    [ "setDescription", "a00006.html#afe66211bf0ca450f9bf80556bf54968a", null ],
    [ "setImageFile", "a00006.html#a138bc5e80dda34e870183f7c016c565a", null ],
    [ "setName", "a00006.html#a6fb035d7103acd537ba1e1e2ca61e1e3", null ],
    [ "toHtml", "a00006.html#a45492403d449bbd9dea4e9c567591687", null ],
    [ "toText", "a00006.html#a9fcc10c120e3ee0d947be19fe3e023e5", null ],
    [ "toXml", "a00006.html#a797ce6bb5f6f2798640ef505ed1ee644", null ]
];