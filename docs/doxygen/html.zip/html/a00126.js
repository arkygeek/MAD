var a00126 =
[
    [ "MadDataClassification", "a00002.html", null ],
    [ "MadMainWindow", "a00013.html", null ],
    [ "MadTextDisplayForm", "a00023.html", null ]
];