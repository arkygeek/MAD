var a00017 =
[
    [ "MadStateVars", "a00017.html#afe69eeedf32caebbbd6bdacd3740c8f7", null ],
    [ "MadStateVars", "a00017.html#a54076d5f932fcbfce45d7224cd96edca", null ],
    [ "cropCategories", "a00017.html#a3d2f1a3fc0358b9b389ad8db1156eb64", null ],
    [ "fromXml", "a00017.html#a43ed35dc578eeb078847d4b682ba4cba", null ],
    [ "observationCategories", "a00017.html#a6a7cb07d8656f94e8b979419b70401f7", null ],
    [ "operator=", "a00017.html#ad84784a03f89004b5d56841a675257b5", null ],
    [ "setCropCategories", "a00017.html#a27ff03d5b9d20a7d277a3d54d43c1ab5", null ],
    [ "setObservationCategories", "a00017.html#ab229d19c85d59daaf754329866bb13fd", null ],
    [ "setSoilCategories", "a00017.html#a0a0370ec347ea20433329b73bd26350d", null ],
    [ "setSurfaceFluxesCategories", "a00017.html#aaebd0daee994ba70531a4c904fc4df41", null ],
    [ "soilCategories", "a00017.html#a62d0104882b20642e20a6e49ea484c0b", null ],
    [ "surfaceFluxesCategories", "a00017.html#a2e11f493e149c056f87ed53bbb93ccc8", null ],
    [ "toHtml", "a00017.html#af8668c4254b0781c68dbc5a3e56f5331", null ],
    [ "toText", "a00017.html#ae6a0d5cc244d4b0d5e760144e5c9a1aa", null ],
    [ "toXml", "a00017.html#abc3dc6f8bae46af546755a97745aaeb2", null ]
];