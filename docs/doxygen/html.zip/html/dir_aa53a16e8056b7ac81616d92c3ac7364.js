var dir_aa53a16e8056b7ac81616d92c3ac7364 =
[
    [ "maddataclassification.cpp", "a00057.html", [
      [ "cultivation", "a00004.html", "a00004" ],
      [ "phenology", "a00023.html", "a00023" ],
      [ "previousCrop", "a00024.html", "a00024" ],
      [ "initialValues", "a00005.html", "a00005" ],
      [ "soil", "a00032.html", "a00032" ],
      [ "siteData", "a00028.html", "a00028" ],
      [ "weatherData", "a00042.html", "a00042" ],
      [ "stateVariables", "a00035.html", [
        [ "crop", "a00001.html", "a00001" ],
        [ "observations", "a00021.html", "a00021" ],
        [ "soil", "a00031.html", "a00031" ],
        [ "surfaceFluxes", "a00038.html", "a00038" ]
      ] ],
      [ "crop", "a00001.html", "a00001" ],
      [ "soil", "a00031.html", "a00031" ],
      [ "surfaceFluxes", "a00038.html", "a00038" ],
      [ "observations", "a00021.html", "a00021" ]
    ] ],
    [ "maddataclassification.h", "a00058.html", [
      [ "MadDataClassification", "a00009.html", "a00009" ]
    ] ],
    [ "madtextdisplayform.cpp", "a00059.html", null ],
    [ "madtextdisplayform.h", "a00060.html", [
      [ "MadTextDisplayForm", "a00017.html", "a00017" ]
    ] ]
];