var a00037 =
[
    [ "mCH4Loss", "a00037.html#a1f9a2b4f18b1f411af2b6e0785461905", null ],
    [ "mEt", "a00037.html#aa059f730c186ed1f5f6e1db4b78d4d28", null ],
    [ "mN2Loss", "a00037.html#a23d916c768ad0d2c56c250bae7d60bff", null ],
    [ "mN2OLosse", "a00037.html#abe27dad429d642a7e91734c6037d1c9b", null ],
    [ "mNH3Loss", "a00037.html#a9c867d4a12089af48569d372c76c6916", null ]
];