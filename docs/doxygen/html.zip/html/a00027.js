var a00027 =
[
    [ "mCrop", "a00027.html#ac705152db748f7b09c680e47e77abe09", null ],
    [ "mFertilisation", "a00027.html#a544d883317c7b9e87c1cba63111370e9", null ],
    [ "mHarvestDate", "a00027.html#abcc096cf9cc7e7b0fefba1e70397e2c3", null ],
    [ "mIrrigation", "a00027.html#a4f8c43b2b03075b8dfda05ee26d9489f", null ],
    [ "mResidueMgmt", "a00027.html#a5c7417bc209b994d9b2a570777c7a3b0", null ],
    [ "mSowingDate", "a00027.html#ad2f1e31e45f6412dfe633b076b3e5846", null ],
    [ "mYield", "a00027.html#af1662174bd2f2f9949d75a0bc8836bf4", null ]
];